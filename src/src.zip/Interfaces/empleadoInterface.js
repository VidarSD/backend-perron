class EmpleadoInterface {
     createEmpleado(data){}
     updateEmeplado(id,data){}
     deleteEmpleado(id){}
     getAllEmpleados(){}
     getEmpleadoById(id){}
     getEmpleadoByUsername(username){}
     getEmpleadoByRol(rol){}

}
export default EmpleadoInterface