class EmpleadoModel {
    constructor(id,nombre,apaterno,amaterno,direccion,telefono,ciudad,estado,usuario,password,rol,imagen){
        this.id=id
        this.nombre=nombre
        this.apaterno=apaterno
        this.amaterno=amaterno
        this.direccion = direccion
        this.telefono = telefono
        this.ciudad = ciudad
        this.estado = estado
        this.usuario = usuario
        this.password =password
        this.rol =rol
        this.imagen = imagen
    }
    
}